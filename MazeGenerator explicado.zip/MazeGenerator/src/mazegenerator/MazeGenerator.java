
package mazegenerator;
import java.awt.event.ActionListener;
import java.awt.Graphics;

import javax.swing.*;

/**
 *
 * @author Martin Ojanguren
 */
public class MazeGenerator extends JFrame { //la interfaz

    private JTextField x = new JTextField();
    private JTextField y = new JTextField();
    private JButton generar = new JButton("Generar");
    private JLabel label = new JLabel("Ingrese la dimension del laberinto");
    private boolean flag = false;
    private JLabel dimension = new JLabel("Dimension: m x n");
    
    public MazeGenerator(){ //el constructor de la interfaz
        super("Laberinto");
        setSize(1000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(null);
        add(x);
        add(generar);
        x.setBounds(50, 50, 50, 30);
        generar.setBounds(50, 100, 100, 30);
        add(label);
        label.setBounds(50, 200, 200, 30);
        y.setBounds(120, 50, 50, 30);
        add(y);
        add(dimension);
        dimension.setBounds(50, 20, 100, 30);

        
        generar.addActionListener(new ActionListener() { //el boton que genera el laberinto
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                flag = true;
                repaint(); 
            }
        });
    }


    @Override
    public void paint(Graphics g){ // pinta el laberinto
        super.paint(g);
        if (flag){


            try {
                int m = Integer.parseInt(x.getText());
                int n = Integer.parseInt(y.getText());

                // m and n are not multiples of 10 return
                if (m % 5 != 0 || n % 5 != 0){
                    JOptionPane.showMessageDialog(null, "Las dimensiones deben ser multiplos de 5");
                    return;
                }else if ( m > 100 || n > 100){
                    JOptionPane.showMessageDialog(null, "Las dimensiones no pueden superar las 100 filas o columnas");
                    return;
                }

                Maze maze = new Maze(m, n);
                maze.generateMaze(maze.getCells()[0][0]);

                Cell[][] cells = maze.getCells();

                for (int i = 0; i< m; i++){ //asigna los colores
                    for (int j = 0; j < n; j++){

                        if (cells[i][j].isStart()){ //pinta el inicio
                            g.setColor(java.awt.Color.GREEN);
                            g.fillRect((cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120, 500 / m, 500 / n);
                        }
                        if (cells[i][j].isEnd()){ //pinta el final
                            g.setColor(java.awt.Color.RED); 
                            g.fillRect((cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120, 500 / m, 500 / n);
                        }

                        // pinta los bordes

                        g.setColor(java.awt.Color.BLACK);
                        g.drawLine((cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120, (cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120 + 500 / n);
                        g.drawLine((cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120, (cells[i][j].getX() * 500 / m)+270 + 500 / m, (cells[i][j].getY() * 500 / n)+120);

                        // pinta lineas blancas cuando hay un camino entre celdas
                        if (cells[i][j].getLados()[0]){
                            g.setColor(java.awt.Color.WHITE);
                            g.drawLine((cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120, (cells[i][j].getX() * 500 / m)+270 + 500 / m, (cells[i][j].getY() * 500 / n)+120);
                        }
                        if (cells[i][j].getLados()[1]){
                            g.setColor(java.awt.Color.WHITE);
                            g.drawLine((cells[i][j].getX() * 500 / m)+270 + 500 / m, (cells[i][j].getY() * 500 / n)+120, (cells[i][j].getX() * 500 / m)+270 + 500 / m, (cells[i][j].getY() * 500 / n)+120 + 500 / n);
                        }
                        if (cells[i][j].getLados()[2]){
                            g.setColor(java.awt.Color.WHITE);
                            g.drawLine((cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120 + 500 / n, (cells[i][j].getX() * 500 / m)+270 + 500 / m, (cells[i][j].getY() * 500 / n)+120 + 500 / n);
                        }
                        if (cells[i][j].getLados()[3]){
                            g.setColor(java.awt.Color.WHITE);
                            g.drawLine((cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120, (cells[i][j].getX() * 500 / m)+270, (cells[i][j].getY() * 500 / n)+120 + 500 / n);
                        }
                        
                        
                    }
            }

            flag = false;
        } catch (Exception e) { //para que se lo acepte enteros
            JOptionPane.showMessageDialog(null, "Ingrese un numero entero");
        }
        }
    }




 
    public static void main(String[] args) {
        
        MazeGenerator maze = new MazeGenerator();
        
    }

    
}
