package mazegenerator;



public class Cell {
    

    private int x;
    private int y;
    private boolean visited; //se utilizo se usa para ver si ya paso esa celda en el recorrido 
    private boolean isWall; // se utilizo para verificar si es una pared
    private boolean isPath;
    private boolean isStart; //se utilizo para ver si es el inicio
    private boolean isEnd; //se utilizo para ver si es el final
    private Cell next; 
    private boolean lados[] = {true, true, true, true}; //se utilizo para hacer las paredes entre celdas
    private boolean puertas[] = {false,false,false,false};
    private Cell below,top,right,left; //se utilizo para ver los vecinos


//asigna las coordenadas, para ver donde esta parado
    public Cell(int x, int y) {
        this.x = x;
        this.y = y;
        this.visited = false;
        this.isWall = false;
        this.isPath = false; //no se utilizo
        this.isStart = false;
        this.next = null; //no se utilizo
    }

//se utilizan para pintar
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
// ver si ha sido visitado
    public boolean isVisited() {
        return visited;
    }
//asigna si esta visitado o no 
    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    public Cell getNext() { //no se utilizo
        return next;
    }

    public void setNext(Cell next) {  //no se utilizo
        this.next = next;
    }

    public boolean isWall() { //para asignar que fuera una pared
        return isWall;
    }

    public void setWall(boolean isWall) { //asigna que fuera una pared
        this.isWall = isWall;
    }

    public boolean isPath() { //no se utilizaron
        return isPath;
    }

    public void setPath(boolean isPath) { //no se utilizaron 
        this.isPath = isPath;
    }

    public boolean isStart() { //para ver el inicio
        return isStart;
    }

    public void setStart(boolean isStart) { //para asignar el inicio
        this.isStart = isStart;
    }

    public boolean isEnd() { //para ver el final
        return isEnd;
    }

    public void setEnd(boolean isEnd) { //para asignar el final 
        this.isEnd = isEnd;
    }

    public boolean[] getLados() { //para asignar las paredes al hacer el recorrido
        return lados;
    }

    public void setLados(boolean[] lados) { //no se utilizo
        this.lados = lados;
    }

    public boolean[] getPuertas() { //no se utilzo
        return puertas;
    }

    public void setPuertas(boolean[] puertas) { //no se utilzo
        this.puertas = puertas;
    }

    public Cell getBelow() { //para obtener vecinos de abajo, retorna celda
        return below;
    }

    public void setBelow(Cell below) { //lo asigna abajo
        this.below = below;
    }

    public Cell getTop() { //lo obtiene arriba 
        return top;
    }

    public void setTop(Cell top) { //asigna el de arriba
        this.top = top;
    }

    public Cell getRight() { //obtiene el de la derecha
        return right;
    }

    public void setRight(Cell right) { //asigna el de la derecha
        this.right = right;
    }

    public Cell getLeft() { //obtiene el de la izquierda
        return left;
    }

    public void setLeft(Cell left) { //asigna el de la izquierda
        this.left = left;
    }

    public void printVecinos() { //se utiulizo para ver si asignaba bien los vecinos
        System.out.println("x: " + x + " y: " + y);
        if (below != null) {
            System.out.println("below: " + below.getX() + " " + below.getY());
        }
        if (top != null) {
            System.out.println("top: " + top.getX() + " " + top.getY());
        }
        if (right != null) {
            System.out.println("right: " + right.getX() + " " + right.getY());
        }
        if (left != null) {
            System.out.println("left: " + left.getX() + " " + left.getY());
        }
    }


    public void setLado(int i, boolean b) {  //no se utilizo
        lados[i] = b;
    }



    public void printLados() { //se utilizo para ver las paredes que tenian
        System.out.println("x: " + x + " y: " + y);
        System.out.println("lado 0: " + lados[0]);
        System.out.println("lado 1: " + lados[1]);
        System.out.println("lado 2: " + lados[2]);
        System.out.println("lado 3: " + lados[3]);
    }

    public Cell[] getNeighbors() { //se utilizo para obtener los vecinos de una celda en especifico
        Cell[] vecinos = new Cell[4];
        vecinos[0] = below;
        vecinos[1] = top;
        vecinos[2] = right;
        vecinos[3] = left;
        return vecinos;
    } 

    public void removeWall(Cell next){ //no se utilizo

        if(next.getX() == this.getX() && next.getY() == this.getY() - 1){
            this.setLado(0, false);
            next.setLado(1, false);
        }
        if(next.getX() == this.getX() && next.getY() == this.getY() + 1){
            this.setLado(1, false);
            next.setLado(0, false);
        }
        if(next.getX() == this.getX() + 1 && next.getY() == this.getY()){
            this.setLado(2, false);
            next.setLado(3, false);
        }
        if(next.getX() == this.getX() - 1 && next.getY() == this.getY()){
            this.setLado(3, false);
            next.setLado(2, false);
        }

    }



}
