package mazegenerator;

public class Maze {

    private AdyancencyList adyancencyList;
    private Cell[][] cells;
    private int xSize;
    private int ySize;

    public Maze(int xSize, int ySize) { //genera un labarito que va a tener todas paredew excepto el inicio y el fin
        this.adyancencyList = new AdyancencyList();
        this.xSize = xSize;
        this.ySize = ySize;
        cells = new Cell[xSize][ySize];
        for ( int i = 0; i< xSize; i++){
            for (int j = 0; j < ySize; j++){
                cells[i][j] = new Cell(i,j);
                cells[i][j].setWall(true);
                // set the start and end of the maze
                if (i == 0 && j == 0){
                    cells[i][j].setStart(true);
                    cells[i][j].setWall(false);
                }
                if (i == xSize-1 && j == ySize-1){
                    cells[i][j].setEnd(true);
                    cells[i][j].setWall(false);
                }

            }
        }


        //assign the neighbors 

        for ( int i = 0; i< xSize; i++){
            for (int j = 0; j < ySize; j++){
                if(i == 0){
                    cells[i][j].setLeft(null);
                }else{
                    cells[i][j].setLeft(cells[i-1][j]);
                }
                if(i == xSize-1){
                    cells[i][j].setRight(null);
                }else{
                    cells[i][j].setRight(cells[i+1][j]);
                }
                if(j == 0){
                    cells[i][j].setTop(null);
                }else{
                    cells[i][j].setTop(cells[i][j-1]);
                }
                if(j == ySize-1){
                    cells[i][j].setBelow(null);
                }else{
                    cells[i][j].setBelow(cells[i][j+1]);
                }
            }
        }

    }

    public int randomInt(int min, int max){ //para obtener un numero al azar entre un rango

        return (int) (Math.random() * (max - min + 1) + min);


    }

    public Cell[][] getCells(){ //se utilizo para que retornara la matriz de todas las celdas
        return this.cells;
    } 

    // generate the maze recursively using backtracking
    // es una funcion recursiva que genera el laberinto basado en backtracking,
    // este algoritmo cada vez que entra a la funcion pone como visitada la celda actual
    // elige un vecino al azar y le asigna los lados (paredes) entre celdas
    // para la celda y el lado que esta colocando una pared lo hace tambien para el vecino
    // siempre se mueve hacia un vecino al azar si y solo si no es null ni esta visitado
    
    public void generateMaze(Cell currentCell){ 
        
        currentCell.setVisited(true);
        currentCell.setWall(false);
        adyancencyList.add(currentCell);

        Cell[] neighbors = currentCell.getNeighbors();
        
        while (neighbors[0] != null || neighbors[1] != null || neighbors[2] != null || neighbors[3] != null){
            int random = randomInt(0,3);
            if (neighbors[random] != null && !neighbors[random].isVisited()){
                currentCell.getLados()[random] = false;
                neighbors[random].getLados()[(random+2)%4] = false;
                generateMaze(neighbors[random]);
            }else{
                neighbors[random] = null;
            }
            // si se llega al final de laberinto, se termina
            if (currentCell.isEnd()){
                return;
            }
        }
    
    }

    public int dimensions(){ //no se utilizo
        return xSize * ySize;
    }


    public AdyancencyList getAdyancencyList() { //se utilizo para pruebas nada mas
        return adyancencyList;
    }


    public int getxSize() { //se utilizo para ver las dimensiones de los laberintos
        return xSize;
    }

    public void setxSize(int xSize) { //se utilizo para ver las dimensiones de los laberintos
        this.xSize = xSize;
    }

    public int getySize() { //se utilizo para ver las dimensiones de los laberintos
        return ySize;
    }

    public void setySize(int ySize) { //se utilizo para ver las dimensiones de los laberintos
        this.ySize = ySize;
    }


}
